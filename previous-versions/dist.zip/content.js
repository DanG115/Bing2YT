let redirectAttempts = 0;
const MAX_REDIRECT_ATTEMPTS = 10;
const BING2YT_CONFIG = {
    selectors: {
        searchForm: ".b_searchboxForm",
        inputBox: "#sb_form_q",
        videoTitle: "div.title[href*='youtube.com']",
        videoLink: "a[href*='youtube.com'], a.source.tosurl",
        embeddedIframe: "iframe[src*='youtube.com/embed/'], div.ep iframe[src*='youtube.com']",
        viewSource: ".action.view_source.nofocus",
        videoResult: ".dg_u, .vrhdata",
    },
    youtubeUrl: "https://www.youtube.com/watch?v=",
    youtubeSearchUrl: "https://www.youtube.com/results?search_query=",
    debounceTime: 150
};
const bing2ytState = {
    developerMode: false,
    redirectEnabled: false,
    observers: {
        redirect: null,
        ytIcon: null
    }
};
const logDebug = (...args) => bing2ytState.developerMode && console.log("[Bing2YT]", ...args);
const extractYouTubeId = (url) => {
    try {
        const decoded = decodeURIComponent(url);
        const match = decoded.match(/(?:embed\/|v=|youtu\.be\/)([\w-]{11})/);
        return match ? match[1] : null;
    }
    catch {
        return null;
    }
};
const isBingVideoPage = () => {
    const href = window.location.href;
    return href.includes("/riverview/") || href.includes("/watch/") || href.includes("view=detail");
};
const processRedirect = (event) => {
    logDebug("Processing redirect...");
    if (!bing2ytState.redirectEnabled || !isBingVideoPage())
        return;
    if (bing2ytState.redirectingNow) {
        logDebug("Redirect already in progress, skipping.");
        return;
    }
    if (redirectAttempts >= MAX_REDIRECT_ATTEMPTS) {
        logDebug("Max redirect attempts reached, waiting for iframe load...");
        return;
    }
    redirectAttempts++;
    logDebug(`Redirect attempt #${redirectAttempts}`);
    const iframe = document.querySelector(BING2YT_CONFIG.selectors.embeddedIframe);
    if (iframe) {
        const videoId = extractYouTubeId(iframe.src);
        if (videoId) {
            logDebug(`Redirecting to YouTube video with ID: ${videoId}`);
            bing2ytState.redirectingNow = true;
            showRedirectToast("Redirecting to YouTube video!");
            window.location.href = `${BING2YT_CONFIG.youtubeUrl}${videoId}`;
            return;
        }
    }
    if (redirectAttempts < MAX_REDIRECT_ATTEMPTS) {
        logDebug("Redirect failed — retrying shortly...");
        setTimeout(() => processRedirect(), 800);
    }
    if (event?.type === "click") {
        const videoElement = event.target.closest(BING2YT_CONFIG.selectors.videoResult);
        if (!videoElement)
            return;
        const link = videoElement.querySelector(BING2YT_CONFIG.selectors.videoLink);
        if (link?.dataset.instInfo) {
            try {
                const data = JSON.parse(link.dataset.instInfo);
                const ytUrl = data.url ? decodeURIComponent(data.url) : null;
                if (ytUrl && ytUrl.includes("youtube.com")) {
                    logDebug(`Redirecting to YouTube URL: ${ytUrl}`);
                    bing2ytState.redirectingNow = true;
                    showRedirectToast("Redirecting to YouTube video!");
                    event.preventDefault();
                    window.location.replace(ytUrl);
                }
            }
            catch (err) {
                logDebug("Failed to parse data-inst-info:", err);
            }
        }
    }
};
document.querySelectorAll('.title').forEach(el => {
    el.removeAttribute('title');
});
const YT_PREVIEW_CONFIG = {
    previewDelay: 300,
    fadeDuration: 200,
    maxWidth: "320px"
};
let ytPreviewTimeout = null;
let ytPreviewElement = null;
const YTPreview = () => {
    const div = document.createElement("div");
    div.id = "yt-preview-tooltip";
    Object.assign(div.style, {
        position: "fixed",
        zIndex: "999999",
        background: "#1f1f1f",
        color: "#fff",
        padding: "8px",
        borderRadius: "8px",
        boxShadow: "0 4px 12px rgba(0,0,0,0.4)",
        maxWidth: YT_PREVIEW_CONFIG.maxWidth,
        display: "none",
        transition: `opacity ${YT_PREVIEW_CONFIG.fadeDuration}ms ease`,
        opacity: "0",
        fontSize: "13px"
    });
    document.body.appendChild(div);
    return div;
};
const showYTPreview = async (link, event) => {
    const videoUrl = link.href;
    if (!videoUrl.includes("youtube.com"))
        return;
    try {
        const oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(videoUrl)}&format=json`;
        const response = await fetch(oembedUrl);
        if (!response.ok)
            throw new Error(`Fetch failed: ${response.status}`);
        const data = await response.json();
        if (!ytPreviewElement)
            ytPreviewElement = YTPreview();
        ytPreviewElement.innerHTML = `
      <div style="display:flex;gap:8px;align-items:flex-start;">
        <img src="${data.thumbnail_url}" width="100" style="border-radius:6px;object-fit:cover;" />
        <div style="flex:1;overflow:hidden;">
          <div style="font-weight:600;font-size:14px;line-height:1.2;margin-bottom:4px;">${data.title}</div>
          <div style="font-size:12px;color:#ccc;">${data.author_name}</div>
        </div>
      </div>
    `;
        ytPreviewElement.style.top = `${event.clientY + 15}px`;
        ytPreviewElement.style.left = `${event.clientX + 15}px`;
        ytPreviewElement.style.display = "block";
        requestAnimationFrame(() => {
            ytPreviewElement.style.opacity = "1";
        });
    }
    catch (err) {
        logDebug("YT Preview fetch error:", err);
    }
};
const hideYTPreview = () => {
    if (!ytPreviewElement)
        return;
    ytPreviewElement.style.opacity = "0";
    setTimeout(() => {
        ytPreviewElement.style.display = "none";
    }, YT_PREVIEW_CONFIG.fadeDuration);
};
const setupYTPreviewListeners = () => {
    logDebug("Setting up YouTube preview hover listeners");
    document.addEventListener("mouseover", (event) => {
        const link = event.target.closest(BING2YT_CONFIG.selectors.videoTitle);
        if (!link)
            return;
        if (link.hasAttribute("title"))
            link.removeAttribute("title");
        if (ytPreviewTimeout)
            clearTimeout(ytPreviewTimeout);
        ytPreviewTimeout = window.setTimeout(() => {
            const fakeLink = {
                href: link.getAttribute("href")
            };
            showYTPreview(fakeLink, event);
        }, YT_PREVIEW_CONFIG.previewDelay);
    });
    document.addEventListener("mousemove", (event) => {
        if (ytPreviewElement && ytPreviewElement.style.display === "block") {
            ytPreviewElement.style.top = `${event.clientY + 15}px`;
            ytPreviewElement.style.left = `${event.clientX + 15}px`;
        }
    });
    document.addEventListener("mouseout", (event) => {
        const link = event.target.closest(BING2YT_CONFIG.selectors.videoTitle);
        if (link) {
            if (ytPreviewTimeout)
                clearTimeout(ytPreviewTimeout);
            hideYTPreview();
        }
    });
};
const updateViewSourceIcons = () => {
    logDebug("Updating Bing view source icons to YouTube icons");
    bing2ytState.observers.ytIcon?.disconnect();
    const replaceIcons = () => {
        document.querySelectorAll(BING2YT_CONFIG.selectors.viewSource).forEach((element) => {
            if (!element.classList.contains("yt-replaced")) {
                element.innerHTML = `
          <span class="yt-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" 
              viewBox="0 0 24 24" fill="currentColor">
              <path d="M19.615 3.184C21.239 3.53 22.488 4.857 22.837 6.524c.376 1.803.376 5.563.376 5.563s0 3.76-.376 5.563c-.349 1.667-1.598 2.994-3.222 3.34C17.5 21.5 12 21.5 12 21.5s-5.5 0-7.615-.33C2.761 20.824 1.512 19.497 1.163 17.83.787 16.027.787 12.267.787 12.267s0-3.76.376-5.563C1.512 4.857 2.761 3.53 4.385 3.184 6.5 2.854 12 2.854 12 2.854s5.5 0 7.615.33zM10 15.5l6-3.5-6-3.5v7z"/>
            </svg>
          </span>`;
                element.classList.add("yt-replaced");
                logDebug("Replaced icon with YouTube icon");
            }
        });
    };
    bing2ytState.observers.ytIcon = new MutationObserver(replaceIcons);
    bing2ytState.observers.ytIcon.observe(document.body, { childList: true, subtree: true });
    replaceIcons();
    logDebug("Observer set for view source icon updates");
};
const createYouTubeSearchButton = () => {
    const btn = document.createElement("button");
    btn.id = "yt-search-btn";
    btn.innerHTML = `
    <svg style="vertical-align:middle;margin-right:6px" width="16" height="16" viewBox="0 0 24 24">
      <path fill="currentColor" d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
    </svg>
    Search on YouTube`;
    Object.assign(btn.style, {
        marginLeft: "8px",
        padding: "6px 12px",
        backgroundColor: "#fff",
        color: "#FF0000",
        border: "1px solid rgba(255, 0, 0, 0.4)",
        borderRadius: "20px",
        cursor: "pointer",
        fontSize: "13px",
        fontWeight: "500",
        marginTop: "8px",
        display: "inline-flex",
        alignItems: "center",
        transition: "all 0.25s ease",
        boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
    });
    btn.onmouseover = () => {
        btn.style.backgroundColor = "#FF0000";
        btn.style.color = "#fff";
        btn.style.borderColor = "#FF0000";
    };
    btn.onmouseout = () => {
        btn.style.backgroundColor = "#fff";
        btn.style.color = "#FF0000";
        btn.style.borderColor = "rgba(255, 0, 0, 0.4)";
    };
    btn.onclick = () => {
        const query = document.querySelector(BING2YT_CONFIG.selectors.inputBox)?.value.trim();
        if (query) {
            logDebug(`Opening YouTube search for: ${query}`);
            window.open(`${BING2YT_CONFIG.youtubeSearchUrl}${encodeURIComponent(query)}`);
        }
    };
    return btn;
};
const showRedirectToast = (message) => {
    const existingBanner = document.getElementById("bing2yt-toast");
    if (existingBanner)
        existingBanner.remove();
    const banner = document.createElement("div");
    banner.id = "bing2yt-toast";
    banner.textContent = message;
    Object.assign(banner.style, {
        position: "fixed",
        top: "0",
        left: "0",
        width: "100%",
        backgroundColor: "#FF0000",
        color: "white",
        fontSize: "15px",
        fontWeight: "600",
        textAlign: "center",
        padding: "10px 0",
        zIndex: "9999",
        opacity: "0",
        transform: "translateY(-100%)",
        transition: "all 0.4s ease"
    });
    document.body.appendChild(banner);
    requestAnimationFrame(() => {
        banner.style.opacity = "1";
        banner.style.transform = "translateY(0)";
    });
    setTimeout(() => {
        banner.style.opacity = "0";
        banner.style.transform = "translateY(-100%)";
        setTimeout(() => banner.remove(), 500);
    }, 3000);
};
const injectYouTubeButton = () => {
    const existingBtn = document.getElementById("yt-search-btn");
    if (existingBtn)
        existingBtn.remove();
    const searchForm = document.querySelector(BING2YT_CONFIG.selectors.searchForm);
    const inputBox = document.querySelector(BING2YT_CONFIG.selectors.inputBox);
    if (searchForm && inputBox) {
        logDebug("Injecting YouTube search button");
        searchForm.insertBefore(createYouTubeSearchButton(), inputBox.nextSibling);
    }
    else {
        logDebug("Search form not found, skipping YouTube button injection");
    }
};
const initRedirectObserver = () => {
    bing2ytState.observers.redirect?.disconnect();
    processRedirect();
    logDebug("Setting up redirect observer");
    bing2ytState.observers.redirect = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === 1 && node.matches(BING2YT_CONFIG.selectors.embeddedIframe)) {
                    processRedirect();
                    logDebug("Detected embedded iframe, processed redirect");
                    return;
                }
            }
        }
    });
    bing2ytState.observers.redirect.observe(document, {
        childList: true,
        subtree: true
    });
};
const initialiseBing2YT = () => {
    if (!window.location.href.includes("bing.com/videos"))
        return;
    if (isBingVideoPage()) {
        document.addEventListener("click", processRedirect, { capture: true });
        initRedirectObserver();
        const ytIconsChecker = document.querySelector(BING2YT_CONFIG.selectors.viewSource);
        if (ytIconsChecker) {
            updateViewSourceIcons();
        }
        else {
            logDebug("No view source icons found on video page");
        }
        logDebug("Initialised Bing2YT for video page");
    }
    else {
        injectYouTubeButton();
        initRedirectObserver();
        setupYTPreviewListeners();
        const ytIconsChecker = document.querySelector(BING2YT_CONFIG.selectors.viewSource);
        if (ytIconsChecker) {
            updateViewSourceIcons();
        }
        else {
            logDebug("No view source icons found on video page");
        }
        logDebug("Initialized Bing2YT for search page");
    }
};
const teardownBing2YT = () => {
    document.removeEventListener("click", processRedirect);
    bing2ytState.observers.redirect?.disconnect();
    bing2ytState.observers.ytIcon?.disconnect();
    document.getElementById("yt-search-btn")?.remove();
    ytPreviewElement?.remove();
    ytPreviewElement = null;
    bing2ytState.redirectingNow = false;
    document.querySelectorAll(".yt-replaced").forEach((el) => {
        el.classList.remove("yt-replaced");
        el.innerHTML = "";
    });
    logDebug("Bing2YT cleaned up");
};
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TOGGLE_REDIRECT") {
        bing2ytState.redirectEnabled = msg.enabled;
        msg.enabled ? initialiseBing2YT() : teardownBing2YT();
    }
});
chrome.storage.sync.get(["redirectEnabled", "devMode"], (data) => {
    bing2ytState.redirectEnabled = !!data.redirectEnabled;
    bing2ytState.developerMode = !!data.devMode;
    if (bing2ytState.redirectEnabled)
        initialiseBing2YT();
});
if (document.readyState === "complete") {
    if (bing2ytState.redirectEnabled)
        initialiseBing2YT();
    logDebug("Bing2YT initialized on load");
}
else {
    logDebug("Bing2YT waiting for DOMContentLoaded");
    document.addEventListener("DOMContentLoaded", () => bing2ytState.redirectEnabled && initialiseBing2YT(), { once: true });
}
