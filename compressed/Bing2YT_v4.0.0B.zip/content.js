const SELECTORS = {
    searchForm: ".b_searchboxForm",
    inputBox: "#sb_form_q",
    videoLink: "a.source.tosurl",
    viewSource: ".action.view_source.nofocus",
};
let developerMode = false;
let redirectEnabled = false;
let redirectObserver = null;
let ytIconObserver = null;
function Clog(...args) {
    if (developerMode) {
        console.log("[Bing2YT]", ...args);
    }
}
function debounce(fn, delay) {
    let timeoutId;
    return (...args) => {
        clearTimeout(timeoutId);
        timeoutId = window.setTimeout(() => fn(...args), delay);
    };
}
function observeBing() {
    if (!redirectEnabled || !document.body)
        return;
    if (redirectObserver)
        redirectObserver.disconnect();
    const checkForYTLink = debounce(() => {
        const link = document.querySelector(SELECTORS.videoLink);
        if (link?.href.includes("youtube.com")) {
            Clog("Redirecting to:", link.href);
            window.location.href = link.href;
            redirectObserver?.disconnect();
        }
    }, 300);
    redirectObserver = new MutationObserver(checkForYTLink);
    redirectObserver.observe(document.body, { childList: true, subtree: true });
    Clog("Started observing Bing video results");
}
function injectYouTubeButton() {
    const existingBtn = document.getElementById("yt-search-btn");
    if (existingBtn)
        existingBtn.remove();
    const searchForm = document.querySelector(SELECTORS.searchForm);
    if (!searchForm) {
        Clog("Search form not found, cannot inject YouTube button");
        return;
    }
    const ytBtn = document.createElement("button");
    ytBtn.id = "yt-search-btn";
    ytBtn.innerHTML = `
    <svg style="vertical-align:middle;margin-right:4px" width="16" height="16" viewBox="0 0 24 24">
      <path fill="white" d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
    </svg>
    Search on YouTube
  `;
    ytBtn.style.cssText = `
    margin-left: 8px;
    padding: 6px 10px;
    background-color: #FF0000;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    margin-top: 8px;
    vertical-align: top;
    transition: background-color 0.3s;
    display: inline-block;
  `;
    ytBtn.onmouseenter = () => (ytBtn.style.backgroundColor = "#CC0000");
    ytBtn.onmouseleave = () => (ytBtn.style.backgroundColor = "#FF0000");
    ytBtn.addEventListener("click", () => {
        const input = document.querySelector(SELECTORS.inputBox);
        const query = encodeURIComponent(input?.value.trim() || "");
        if (query) {
            const url = `https://www.youtube.com/results?search_query=${query}`;
            Clog("Opening YouTube search:", url);
            window.open(url);
        }
    });
    if (searchForm.parentNode) {
        searchForm.parentNode.insertBefore(ytBtn, searchForm.nextSibling);
        Clog("Injected YouTube button");
    }
    else {
        Clog("Could not find parent node to insert YouTube button");
    }
}
function replaceBingViewSourceWithYouTubeIcon() {
    if (ytIconObserver)
        ytIconObserver.disconnect();
    const replaceIcons = debounce(() => {
        document.querySelectorAll(SELECTORS.viewSource).forEach((element) => {
            if (!element.classList.contains("yt-replaced")) {
                const ytSVG = `
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19.615 3.184C21.239 3.53 22.488 4.857 22.837 6.524c.376 1.803.376 5.563.376 5.563s0 3.76-.376 5.563c-.349 1.667-1.598 2.994-3.222 3.34C17.5 21.5 12 21.5 12 21.5s-5.5 0-7.615-.33C2.761 20.824 1.512 19.497 1.163 17.83.787 16.027.787 12.267.787 12.267s0-3.76.376-5.563C1.512 4.857 2.761 3.53 4.385 3.184 6.5 2.854 12 2.854 12 2.854s5.5 0 7.615.33zM10 15.5l6-3.5-6-3.5v7z"/>
          </svg>
        `;
                element.innerHTML = `<span class="yt-icon">${ytSVG}</span>`;
                element.classList.add("yt-replaced");
            }
        });
    }, 300);
    ytIconObserver = new MutationObserver(replaceIcons);
    ytIconObserver.observe(document.body, { childList: true, subtree: true });
    Clog("Started observing for YouTube icon replacement");
}
function clearYouTubeIconReplacements() {
    document.querySelectorAll(`${SELECTORS.viewSource}.yt-replaced`).forEach((element) => {
        element.classList.remove("yt-replaced");
        element.innerHTML = "";
    });
    ytIconObserver?.disconnect();
    ytIconObserver = null;
    Clog("Removed YouTube icons");
}
function waitForSearchBoxAndInject() {
    if (document.querySelector(SELECTORS.searchForm)) {
        injectYouTubeButton();
        return;
    }
    const searchBoxObserver = new MutationObserver((_, obs) => {
        if (document.querySelector(SELECTORS.searchForm)) {
            obs.disconnect();
            injectYouTubeButton();
        }
    });
    searchBoxObserver.observe(document.body, { childList: true, subtree: true });
    Clog("Set up observer for search box injection");
}
function stopObserving() {
    redirectObserver?.disconnect();
    redirectObserver = null;
    clearYouTubeIconReplacements();
    const ytBtn = document.getElementById("yt-search-btn");
    if (ytBtn)
        ytBtn.remove();
    Clog("Stopped observing Bing");
}
function initializeFeatures() {
    observeBing();
    waitForSearchBoxAndInject();
    replaceBingViewSourceWithYouTubeIcon();
}
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TOGGLE_REDIRECT") {
        redirectEnabled = msg.enabled;
        Clog("Redirect enabled:", redirectEnabled);
        if (redirectEnabled) {
            initializeFeatures();
        }
        else {
            stopObserving();
        }
    }
});
chrome.storage.sync.get(["redirectEnabled", "devMode"], (data) => {
    redirectEnabled = data.redirectEnabled === true;
    developerMode = data.devMode === true;
    Clog("Initial redirectEnabled:", redirectEnabled);
    if (redirectEnabled && window.location.href.includes("bing.com/videos")) {
        initializeFeatures();
    }
});
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.devMode) {
        developerMode = changes.devMode.newValue;
        Clog("Developer mode changed:", developerMode);
    }
});
setTimeout(() => {
    if (redirectEnabled && window.location.href.includes("bing.com/videos")) {
        if (!document.getElementById("yt-search-btn")) {
            waitForSearchBoxAndInject();
        }
    }
}, 2000);
