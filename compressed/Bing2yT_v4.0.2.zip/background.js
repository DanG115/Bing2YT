let bgDeveloperMode = false;
function BGlog(...args) {
    if (bgDeveloperMode) {
        console.log("[Bing2YT BG]", ...args);
    }
}
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get(["redirectEnabled", "devMode"], (data) => {
        if (typeof data.redirectEnabled !== "boolean") {
            chrome.storage.sync.set({ redirectEnabled: false }, () => {
                BGlog("redirectEnabled initialized to false");
            });
        }
        bgDeveloperMode = data.devMode === true;
        BGlog("Developer mode in background:", bgDeveloperMode);
    });
});
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.devMode) {
        bgDeveloperMode = changes.devMode.newValue;
        BGlog("Developer mode changed in background:", bgDeveloperMode);
    }
});
