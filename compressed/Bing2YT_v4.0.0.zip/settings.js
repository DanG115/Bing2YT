const DEFAULT_SETTINGS = {
    mode: "light",
    textSize: 16,
    fontFamily: "Inter, 'Segoe UI', Arial, sans-serif",
    devMode: false,
};
const modeSelect = document.getElementById("modeSelect");
const textSizeRange = document.getElementById("textSizeRange");
const textSizeValue = document.getElementById("textSizeValue");
const fontSelect = document.getElementById("fontSelect");
const devModeToggle = document.getElementById("devModeToggle");
const devDisclaimer = document.getElementById("devDisclaimer");
const versionNumber = document.getElementById("versionNumber");
const updateStatus = document.getElementById("updateStatus");
const patchNotesContainer = document.getElementById("releaseNotes");
const updateBtn = document.getElementById("checkUpdatesBtn");
const manifestVersion = chrome.runtime.getManifest().version;
function isVersionLess(current, latest) {
    const curParts = current.split('.').map(Number);
    const latParts = latest.split('.').map(Number);
    for (let i = 0; i < Math.max(curParts.length, latParts.length); i++) {
        const cur = curParts[i] || 0;
        const lat = latParts[i] || 0;
        if (cur < lat)
            return true;
        if (cur > lat)
            return false;
    }
    return false;
}
function applyMode(mode) {
    if (mode === "dark") {
        document.documentElement.classList.add("dark");
    }
    else {
        document.documentElement.classList.remove("dark");
    }
}
function saveSettings(settings) {
    chrome.storage.sync.set(settings);
}
function loadSettings() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(DEFAULT_SETTINGS, (items) => {
            resolve(items);
        });
    });
}
function updateUI(settings) {
    modeSelect.value = settings.mode;
    textSizeRange.value = settings.textSize.toString();
    textSizeValue.textContent = settings.textSize.toString();
    fontSelect.value = settings.fontFamily;
    devModeToggle.checked = settings.devMode;
    applyMode(settings.mode);
    devDisclaimer.style.display = settings.devMode ? "block" : "none";
    versionNumber.textContent = manifestVersion;
}
if (updateBtn) {
    let cooldown = false;
    const cooldownDuration = 60 * 1000;
    updateBtn.addEventListener("click", () => {
        if (cooldown) {
            updateStatus.textContent = "Please wait before checking again.";
            return;
        }
        cooldown = true;
        updateBtn.disabled = true;
        updateStatus.textContent = "Checking for updates...";
        fetch('https://raw.githubusercontent.com/DanG115/Bing2YT/main/release-notes.json')
            .then(res => {
            if (!res.ok)
                throw new Error("Network response was not OK");
            return res.json();
        })
            .then(data => {
            if (isVersionLess(manifestVersion, data.latestVersion)) {
                updateStatus.innerHTML = `<span style="color: orange; font-weight: bold;">
          A new update (${data.latestVersion}) is available! Please download the latest version.
        </span>`;
            }
            else {
                updateStatus.textContent = `You have the latest version (${data.latestVersion}).`;
            }
            versionNumber.textContent = manifestVersion;
            const notes = data.releases?.[data.latestVersion]?.notes || "";
            const formattedNotes = notes
                .replace(/^### (.*)$/gm, '<h3>$1</h3>')
                .replace(/\n/g, "<br>");
            patchNotesContainer.innerHTML = formattedNotes;
        })
            .catch(err => {
            console.error(err);
            updateStatus.textContent = "Failed to check for updates.";
        })
            .finally(() => {
            setTimeout(() => {
                cooldown = false;
                updateBtn.disabled = false;
            }, cooldownDuration);
        });
    });
}
async function checkForUpdatesOnLoad() {
    try {
        const res = await fetch('https://raw.githubusercontent.com/DanG115/Bing2YT/refs/heads/main/release-notes.json');
        if (!res.ok)
            throw new Error("Network response was not OK");
        const data = await res.json();
        if (!data?.latestVersion) {
            throw new Error("Missing 'latestVersion' in response");
        }
        if (isVersionLess(manifestVersion, data.latestVersion)) {
            updateStatus.innerHTML = `<span style="color: orange; font-weight: bold;">
        A new update (${data.latestVersion}) is available! Please download the latest version.
      </span>`;
        }
        else {
            updateStatus.textContent = `You have the latest version (${data.latestVersion}).`;
        }
    }
    catch (error) {
        console.error("Failed to check for updates:", error);
        updateStatus.textContent = "Unable to check for updates.";
    }
}
async function init() {
    const settings = await loadSettings();
    updateUI(settings);
    checkForUpdatesOnLoad();
    modeSelect.addEventListener("change", () => {
        const newMode = modeSelect.value;
        applyMode(newMode);
        saveSettings({ mode: newMode });
    });
    textSizeRange.addEventListener("input", () => {
        const newSize = parseInt(textSizeRange.value, 10);
        textSizeValue.textContent = newSize.toString();
        saveSettings({ textSize: newSize });
    });
    fontSelect.addEventListener("change", () => {
        saveSettings({ fontFamily: fontSelect.value });
    });
    devModeToggle.addEventListener("change", () => {
        const isDev = devModeToggle.checked;
        devDisclaimer.style.display = isDev ? "block" : "none";
        saveSettings({ devMode: isDev });
    });
}
init();
