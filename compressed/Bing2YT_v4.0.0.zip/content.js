const BING2YT_CONFIG = {
    selectors: {
        searchForm: ".b_searchboxForm",
        inputBox: "#sb_form_q",
        videoLink: "a[href*='youtube.com'], a.source.tosurl",
        embeddedIframe: "iframe[src*='youtube.com/embed/'], div.ep iframe[src*='youtube.com']",
        viewSource: ".action.view_source.nofocus",
        videoResult: ".dg_u, .vrhdata"
    },
    youtubeUrl: "https://www.youtube.com/watch?v=",
    youtubeSearchUrl: "https://www.youtube.com/results?search_query=",
    debounceTime: 150
};
const bing2ytState = {
    developerMode: false,
    redirectEnabled: false,
    observers: {
        redirect: null,
        ytIcon: null
    }
};
const debugLog = (...args) => bing2ytState.developerMode && console.log("[Bing2YT]", ...args);
const getVideoId = (url) => {
    const match = url.match(/(?:embed\/|v=)([\w-]{11})/);
    return match ? match[1] : null;
};
const isVideoPage = () => {
    const href = window.location.href;
    return href.includes("/riverview/") || href.includes("/watch/");
};
const handleBingRedirect = (event) => {
    debugLog("Handling Bing redirect");
    if (!bing2ytState.redirectEnabled || !isVideoPage())
        return;
    const iframe = document.querySelector(BING2YT_CONFIG.selectors.embeddedIframe);
    if (iframe) {
        debugLog("Found embedded iframe, checking for YouTube video ID");
        const videoId = getVideoId(iframe.src);
        if (videoId) {
            debugLog(`Redirecting to YouTube video with ID: ${videoId}`);
            window.location.href = `${BING2YT_CONFIG.youtubeUrl}${videoId}`;
            return;
        }
    }
    if (event?.type === 'click') {
        debugLog("Handling click event for Bing video result redirect");
        const videoElement = event.target.closest(BING2YT_CONFIG.selectors.videoResult);
        if (!videoElement)
            return;
        const link = videoElement.querySelector(BING2YT_CONFIG.selectors.videoLink);
        if (link) {
            const urlParams = new URL(link.href).searchParams;
            const actualUrl = urlParams.get('u') || urlParams.get('url');
            if (actualUrl?.includes("youtube.com")) {
                debugLog(`Redirecting to YouTube URL: ${actualUrl}`);
                event.preventDefault();
                window.location.href = actualUrl;
            }
        }
    }
};
const replaceBingViewSourceWithYouTubeIcon = () => {
    debugLog("Replacing Bing view source icon with YouTube icon");
    bing2ytState.observers.ytIcon?.disconnect();
    const replaceIcons = () => {
        document.querySelectorAll(BING2YT_CONFIG.selectors.viewSource).forEach((element) => {
            if (!element.classList.contains("yt-replaced")) {
                const ytSVG = `
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19.615 3.184C21.239 3.53 22.488 4.857 22.837 6.524c.376 1.803.376 5.563.376 5.563s0 3.76-.376 5.563c-.349 1.667-1.598 2.994-3.222 3.34C17.5 21.5 12 21.5 12 21.5s-5.5 0-7.615-.33C2.761 20.824 1.512 19.497 1.163 17.83.787 16.027.787 12.267.787 12.267s0-3.76.376-5.563C1.512 4.857 2.761 3.53 4.385 3.184 6.5 2.854 12 2.854 12 2.854s5.5 0 7.615.33zM10 15.5l6-3.5-6-3.5v7z"/>
          </svg>
        `;
                element.innerHTML = `<span class="yt-icon">${ytSVG}</span>`;
                element.classList.add("yt-replaced");
                debugLog("Replaced Bing view source icon with YouTube icon");
            }
        });
    };
    bing2ytState.observers.ytIcon = new MutationObserver(replaceIcons);
    bing2ytState.observers.ytIcon.observe(document.body, { childList: true, subtree: true });
    debugLog("Setting up observer for Bing view source icon replacement");
    replaceIcons();
};
const setupBingObserver = () => {
    bing2ytState.observers.redirect?.disconnect();
    handleBingRedirect();
    debugLog("Setting up Bing redirect observer");
    bing2ytState.observers.redirect = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === 1 && node.matches(BING2YT_CONFIG.selectors.embeddedIframe)) {
                    handleBingRedirect();
                    debugLog("Detected new embedded iframe, handling redirect");
                    return;
                }
            }
        }
    });
    bing2ytState.observers.redirect.observe(document, {
        childList: true,
        subtree: true,
        attributes: false
    });
};
const createYTButton = () => {
    const btn = document.createElement('button');
    btn.id = 'yt-search-btn';
    btn.innerHTML = `<svg style="vertical-align:middle;margin-right:4px" width="16" height="16" viewBox="0 0 24 24">
      <path fill="white" d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
    </svg>
    Search on YouTube`;
    Object.assign(btn.style, {
        marginLeft: '8px',
        padding: '6px 10px',
        backgroundColor: '#FF0000',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '13px',
        marginTop: '8px',
        verticalAlign: 'top',
        transition: 'background-color 0.3s',
        display: 'inline-block'
    });
    debugLog("Created YouTube search button");
    btn.onclick = () => {
        debugLog("YouTube search button clicked");
        const query = document.querySelector(BING2YT_CONFIG.selectors.inputBox)?.value.trim();
        query && window.open(`${BING2YT_CONFIG.youtubeSearchUrl}${encodeURIComponent(query)}`);
    };
    return btn;
};
const injectYTButton = () => {
    const existing = document.getElementById('yt-search-btn');
    if (existing) {
        debugLog("Removing existing YouTube button");
        existing.remove();
    }
    const searchForm = document.querySelector(BING2YT_CONFIG.selectors.searchForm);
    const inputBox = document.querySelector(BING2YT_CONFIG.selectors.inputBox);
    if (searchForm && inputBox) {
        debugLog("Injecting YouTube button into search bar");
        searchForm.insertBefore(createYTButton(), inputBox.nextSibling);
    }
    else {
        debugLog("Search form or input box not found, injecting into body");
    }
    ;
};
const initBing2YT = () => {
    if (!window.location.href.includes("bing.com/videos"))
        return;
    if (isVideoPage()) {
        document.addEventListener('click', handleBingRedirect, { capture: true });
        debugLog("Bing2YT initialised for video page");
        setupBingObserver();
        replaceBingViewSourceWithYouTubeIcon();
    }
    else {
        debugLog("Bing2YT initialised for search page");
        injectYTButton();
        replaceBingViewSourceWithYouTubeIcon();
    }
};
const cleanupBing2YT = () => {
    document.removeEventListener('click', handleBingRedirect);
    debugLog("Cleaning up Bing2YT");
    bing2ytState.observers.redirect?.disconnect();
    bing2ytState.observers.ytIcon?.disconnect();
    document.getElementById('yt-search-btn')?.remove();
    document.querySelectorAll('.yt-replaced').forEach(el => {
        el.classList.remove('yt-replaced');
        el.innerHTML = '';
    });
    debugLog("Bing2YT cleanup complete");
};
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TOGGLE_REDIRECT") {
        bing2ytState.redirectEnabled = msg.enabled;
        msg.enabled ? initBing2YT() : cleanupBing2YT();
    }
});
chrome.storage.sync.get(["redirectEnabled", "devMode"], (data) => {
    bing2ytState.redirectEnabled = !!data.redirectEnabled;
    bing2ytState.developerMode = !!data.devMode;
    bing2ytState.redirectEnabled && initBing2YT();
});
if (document.readyState === 'complete') {
    bing2ytState.redirectEnabled && initBing2YT();
    debugLog("Bing2YT initialised on DOMContentLoaded");
}
else {
    debugLog("Bing2YT waiting for DOMContentLoaded");
    document.addEventListener('DOMContentLoaded', () => bing2ytState.redirectEnabled && initBing2YT(), { once: true });
}
